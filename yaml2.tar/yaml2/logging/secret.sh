BUCKET_HOST="slobj1.l-cloud.co.kr"
BUCKET_NAME="loki"
BUCKET_PORT="443"
ACCESS_KEY_ID="AKIA5C7CBB2197AB9EAB"
SECRET_ACCESS_KEY="fywLLZoU1hCPemIIqf/cB7OAKSHCwFx1cfzIdFqS"

oc create -n openshift-logging secret generic loki-secret \
--from-literal=access_key_id="${ACCESS_KEY_ID}" \
--from-literal=access_key_secret="${SECRET_ACCESS_KEY}" \
--from-literal=bucketnames="${BUCKET_NAME}" \
--from-literal=endpoint="https://${BUCKET_HOST}:${BUCKET_PORT}" 
